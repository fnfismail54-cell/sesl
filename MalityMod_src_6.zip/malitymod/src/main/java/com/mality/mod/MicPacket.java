package com.mality.mod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;

/** İstemciden sunucuya: sesle söylenen metin, sohbette görünmeden en yakın Mality'ye gider. */
public record MicPacket(String text) {
    public static void encode(MicPacket p, FriendlyByteBuf b) {
        b.writeUtf(p.text(), 256);
    }

    public static MicPacket decode(FriendlyByteBuf b) {
        return new MicPacket(b.readUtf(256));
    }

    public static void handle(MicPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            String raw = p.text().trim();
            if (raw.isEmpty()) return;
            List<MalityEntity> list = sp.serverLevel().getEntitiesOfClass(MalityEntity.class,
                    sp.getBoundingBox().inflate(Config.CHAT_RANGE.get()));
            list.stream().min(Comparator.comparingDouble(m -> m.distanceToSqr(sp)))
                    .ifPresent(m -> m.hear(sp, raw, MalityEntity.fold(raw)));
        });
        ctx.get().setPacketHandled(true);
    }
}
