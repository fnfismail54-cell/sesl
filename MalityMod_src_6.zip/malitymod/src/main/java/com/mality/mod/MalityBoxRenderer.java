package com.mality.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Mavi kutu (küp). Açılırken titrer. */
public class MalityBoxRenderer extends EntityRenderer<MalityBoxEntity> {
    private static final ResourceLocation TEX = new ResourceLocation(MalityMod.MODID, "textures/entity/mality_box.png");

    public MalityBoxRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.4F;
    }

    @Override
    public ResourceLocation getTextureLocation(MalityBoxEntity e) {
        return TEX;
    }

    @Override
    public void render(MalityBoxEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        float age = e.tickCount + pt;
        if (e.openTicks() >= 0) {
            ps.translate(Math.sin(age * 2.2F) * 0.04D, 0.0D, Math.cos(age * 2.7F) * 0.04D);
            ps.mulPose(Axis.ZP.rotationDegrees((float) Math.sin(age * 1.7F) * 4.0F));
        }
        ps.translate(0.0D, 0.45D, 0.0D);
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        SphereRender.box(vc, ps, -0.45F, -0.45F, -0.45F, 0.45F, 0.45F, 0.45F, light);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
