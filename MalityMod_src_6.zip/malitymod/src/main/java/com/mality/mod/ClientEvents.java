package com.mality.mod;

import net.minecraftforge.api.distmarker.Dist;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MalityMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(MalityMod.MALITY.get(), MalityRenderer::new);
        event.registerEntityRenderer(MalityMod.BOX.get(), MalityBoxRenderer::new);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        ClientMic.TALK_KEY = new KeyMapping("key.malitymod.talk", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_M, "key.categories.malitymod");
        event.register(ClientMic.TALK_KEY);
    }
}
