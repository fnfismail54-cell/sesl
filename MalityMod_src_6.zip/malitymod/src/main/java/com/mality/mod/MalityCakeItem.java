package com.mality.mod;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Malitynin Süper Keki: bulantı + rastgele (uçak / tavşan / osuruk), zehirliyse biraz zehir. */
public class MalityCakeItem extends Item {
    public MalityCakeItem() {
        super(new Item.Properties()
                .stacksTo(16)
                .food(new FoodProperties.Builder()
                        .nutrition(6)
                        .saturationMod(0.6F)
                        .alwaysEat()
                        .build()));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        CompoundTag tag = stack.getTag();
        boolean poison = tag != null && tag.getBoolean("Poison");
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide) {
            entity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0)); // midemiz bulanır (10 sn)
            if (poison) entity.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0)); // ölümcül değil
            int r = level.random.nextInt(3);
            if (r == 0) { // UÇAK
                entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 100, 0));
                entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 400, 0));
                tell(entity, "Uçağa dönüştün! Havalanıyorsun!");
            } else if (r == 1) { // TAVŞAN
                entity.addEffect(new MobEffectInstance(MobEffects.JUMP, 200, 5));
                entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1));
                entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 260, 0));
                tell(entity, "Tavşana dönüştün! Zıpla zıpla!");
            } else { // OSURUK
                entity.getPersistentData().putInt("malityFart", 200);
                tell(entity, "Karnın gurulduyor... prrrt!");
            }
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SNEEZE, entity.getX(), entity.getY() + 1.0, entity.getZ(), 12, 0.3, 0.3, 0.3, 0.05);
            }
        }
        return result;
    }

    private static void tell(LivingEntity e, String msg) {
        if (e instanceof Player p) p.displayClientMessage(Component.literal("\u00A7d" + msg), true);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains("Ingredients", Tag.TAG_LIST)) {
            ListTag list = tag.getList("Ingredients", Tag.TAG_STRING);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(list.getString(i));
            }
            tips.add(Component.literal("İçinde: " + sb).withStyle(ChatFormatting.GRAY));
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
